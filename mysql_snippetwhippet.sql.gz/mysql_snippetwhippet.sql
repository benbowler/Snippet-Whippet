-- MySQL dump 10.11
--
-- Host: localhost    Database: snippetwhippet
-- ------------------------------------------------------
-- Server version	5.0.51a-3ubuntu5.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `prelaunch`
--

DROP TABLE IF EXISTS `prelaunch`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `prelaunch` (
  `id` int(100) NOT NULL auto_increment,
  `date` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `email` varchar(100) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `prelaunch`
--

LOCK TABLES `prelaunch` WRITE;
/*!40000 ALTER TABLE `prelaunch` DISABLE KEYS */;
INSERT INTO `prelaunch` (`id`, `date`, `email`) VALUES (1,'2009-10-29 12:09:47','jack.wh@virgin.net'),(3,'2009-11-17 14:59:52','j.cross92@gmail.com'),(4,'2009-11-23 01:30:25','nathanielrosa@gmail.com');
/*!40000 ALTER TABLE `prelaunch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `projects` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(250) default NULL,
  `creatorid` int(9) NOT NULL,
  `date` timestamp NULL default CURRENT_TIMESTAMP,
  `confirmid` varchar(10) NOT NULL,
  `adminid` varchar(100) NOT NULL,
  `memberid` varchar(100) NOT NULL,
  `viewerid` varchar(100) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `projects`
--

LOCK TABLES `projects` WRITE;
/*!40000 ALTER TABLE `projects` DISABLE KEYS */;
INSERT INTO `projects` (`id`, `name`, `creatorid`, `date`, `confirmid`, `adminid`, `memberid`, `viewerid`) VALUES (2,'Test Project',1,'2009-10-04 20:15:10','','','',''),(21,'Testuiouio',1,'2009-10-06 19:10:10','','','',''),(22,'lkjlkj',1,'2009-10-06 20:51:36','','','',''),(23,'lkjlkj',1,'2009-10-06 20:53:24','','','',''),(24,'lkjlkj',1,'2009-10-06 20:53:28','','','',''),(25,'lkjlkj',1,'2009-10-06 20:53:34','','','',''),(26,'Test Email',1,'2009-10-06 21:20:25','','','',''),(37,'A Nice Project',2,'2009-11-20 17:19:27','','','',''),(28,'New',1,'2009-10-07 20:23:49','','','',''),(38,'Shizza',1,'2009-11-26 23:18:09','bghx3qt','1','',''),(39,'Shizza2',1,'2009-11-26 23:19:01','esik3rf','1','',''),(40,'Shizza3',1,'2009-11-26 23:20:13','z0vjwh3','1','','');
/*!40000 ALTER TABLE `projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `snippets`
--

DROP TABLE IF EXISTS `snippets`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `snippets` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(200) NOT NULL,
  `content` varchar(50000) NOT NULL,
  `type` varchar(255) NOT NULL,
  `tags` varchar(15000) NOT NULL,
  `projectid` int(11) NOT NULL,
  `creator` varchar(40) NOT NULL,
  `creatorid` int(9) NOT NULL,
  `date` timestamp NOT NULL default CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `snippets`
--

LOCK TABLES `snippets` WRITE;
/*!40000 ALTER TABLE `snippets` DISABLE KEYS */;
INSERT INTO `snippets` (`id`, `title`, `content`, `type`, `tags`, `projectid`, `creator`, `creatorid`, `date`) VALUES (2,'PHP','<? echo \"PHP\"; ?>','php','php',0,'',1,'2009-10-04 20:13:38'),(3,'Test','Test','text','Test',2,'',1,'2009-10-04 20:15:32'),(4,'kljkjlk','kjljlk','apache','jlkjlkjlk',0,'',4,'2009-10-08 20:27:40'),(12,'Snippet 1','<?php\r\n\r\necho \"This is snippet 1\";\r\n\r\n?>','PHP','sheep snippet blah',37,'',2,'2009-11-20 18:51:01'),(13,'Snippet 2','<?php\r\n\r\necho \"This is snippet 2\";\r\n\r\n?>','PHP','sheep snippet blah2',37,'',2,'2009-11-20 18:51:27'),(14,'Snippet 3','<?php\r\n\r\necho \"This is snippet 3\";\r\n\r\n?>','php','sheep snippet blah3',37,'',2,'2009-11-20 18:51:49'),(15,'Snippet 4','	<?php\r\n\r\necho \"SHOULD NOT APPEAR\";\r\n\r\n?>','php','snippet blah4',37,'',2,'2009-11-20 18:52:12'),(11,'kjhkjh','kjhkjh','html4strict','jkh kh',2,'',1,'2009-11-16 18:01:22');
/*!40000 ALTER TABLE `snippets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `users` (
  `id` int(11) NOT NULL auto_increment,
  `password` varchar(100) default NULL,
  `name` varchar(25) NOT NULL,
  `email` varchar(25) default NULL,
  `regdate` timestamp NULL default CURRENT_TIMESTAMP,
  `enabled` int(1) default '0',
  `confirmid` varchar(100) NOT NULL,
  `plan` int(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `password`, `name`, `email`, `regdate`, `enabled`, `confirmid`, `plan`) VALUES (1,'ca5bae43d01a59d43db9091305f52ce1','Ben Bowler','ben@benbowler.com','2009-10-04 17:19:46',1,'',0),(2,'900150983cd24fb0d6963f7d28e17f72','Ben Clinch','b.clinch@gmail.com','2009-10-04 17:35:12',1,'',0),(3,'1a1dc91c907325c69271ddf0c944bc72','Test','test2@benbowler.com','2009-10-07 21:29:48',1,'jf3dzjy',0),(4,'1a1dc91c907325c69271ddf0c944bc72','Test Me','test1@benbowler.com','2009-10-08 20:25:50',1,'ruvy3c7',0),(5,'1a1dc91c907325c69271ddf0c944bc72','Snippet Wpt','test@snippetwhippet.com','2009-10-08 21:27:49',0,'fedpgvw',0),(6,'1a1dc91c907325c69271ddf0c944bc72','Test Again','test5@benbowler.com','2009-10-08 21:47:56',0,'whxeirk',0),(7,'c4ca4238a0b923820dcc509a6f75849b','1','1@benbowler.com','2009-11-26 14:43:59',1,'axu54jg',0),(8,NULL,'','2@benbowler.com','2009-11-26 23:19:04',0,'',0),(9,NULL,'','3@benbowler.com','2009-11-26 23:20:15',0,'',0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2009-11-29  5:31:35
